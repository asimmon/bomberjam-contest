#!/bin/sh

../../engine/bomberjam --output replay.json "node MyBot.js --logging" "node MyBot.js" "node MyBot.js" "node MyBot.js"