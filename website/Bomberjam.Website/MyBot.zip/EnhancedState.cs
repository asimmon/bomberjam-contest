using System;
using System.Collections.Generic;
using System.Linq;

namespace MyBot
{
    public class EnhancedState
    {
        private readonly string _myPlayerId;
        private GameState _state;

        public EnhancedState(GameState state, string myPlayerId)
        {
            this._state = state;
            this._myPlayerId = myPlayerId;
            this.Tiles = new TileInfo[state.Width * state.Height];

            for (var y = 0; y < this._state.Height; y++)
            for (var x = 0; x < this._state.Width; x++)
            {
                var index = y * this._state.Width + x;

                this.Tiles[index] = new TileInfo
                {
                    X = x,
                    Y = y,
                    Index = index
                };
            }
            
            this.Bombs = new List<Bomb>();
            this.AllPlayers = new List<Player>();
            this.OtherPlayers = new List<Player>();
            this.Bonuses = new List<Bonus>();
        }

        public TileInfo[] Tiles { get; }

        public int Width => this._state.Width;

        public int Height => this._state.Height;

        public int Tick => this._state.Tick;

        public List<Bomb> Bombs { get; }

        public List<Player> AllPlayers { get; }

        public List<Player> OtherPlayers { get; }

        public List<Bonus> Bonuses { get; }
        
        public Player MyPlayer => this._state.Players[this._myPlayerId];

        public bool IsSuddenDeathEnabled => this._state.SuddenDeathEnabled;

        public TileInfo this[int x, int y]
        {
            get => this.Tiles[y * this._state.Width + x];
        }

        public TileInfo this[int index]
        {
            get => this.Tiles[index];
        }

        public void Refresh(GameState state)
        {
            if (this._state.Players.ContainsKey(this._myPlayerId) == false)
                return;
            
            this._state = state;
            
            this.Bombs.Clear();
            this.Bombs.AddRange(this._state.Bombs.Values.OrderBy(b => b.Countdown));
            
            this.AllPlayers.Clear();
            this.AllPlayers.AddRange(this._state.Players.Values.Where(p => p.IsAlive));
            
            this.OtherPlayers.Clear();
            this.OtherPlayers.AddRange(this.AllPlayers.Where(p => p.Id != this._myPlayerId));
            
            this.Bonuses.Clear();
            this.Bonuses.AddRange(this._state.Bonuses.Values);

            foreach (var tile in this.Tiles)
            {
                tile.ThreathenedBySuddenDeath = false;
                tile.TicksBeforeExplosion = int.MaxValue;
                tile.IsWalkable = true;
                tile.TileChar = this._state.Tiles[tile.Index];

                if (tile.TileChar == '#' || tile.TileChar == '+')
                    tile.IsWalkable = false;

                tile.Bomb = this.FindActiveBombAt(tile.X, tile.Y);
                tile.Player = this.FindAlivePlayerAt(tile.X, tile.Y);
                tile.Bonus = this.FindDroppedBonusIndexAt(tile.X, tile.Y);
            
                if (tile.Bomb != null)
                {
                    tile.TicksBeforeExplosion = tile.Bomb.Countdown;
                    
                    if (tile.Bomb.X != this.MyPlayer.X || tile.Bomb.Y != this.MyPlayer.Y)
                    {
                        // tile.MustAvoid = true;
                        // only walkable if the player stands on a bomb he added himself
                        tile.IsWalkable = false;
                    }
                }

                if (tile.Player != null && tile.Player.Id != this.MyPlayer.Id)
                {
                    tile.IsWalkable = false;
                }

                tile.EnemyCount = tile.Player != null && tile.Player.Id != this._myPlayerId ? 1 : 0;
                tile.DestructibleBlockCount = 0;
                tile.IsSafeToDropBomb = true;
                tile.CanBeReachedByBomb = false;
            }

            foreach (var tile in this.Tiles)
            {
                // will be stuck if going here
                var walkableSpotsAround = new List<TileInfo>();
                var otherPlayerAroundCount = 0;
                
                foreach (var direction in AllDirections)
                {
                    if (this.TryGetTileRelativeTo(tile, direction, out var otherTile))
                    {
                        if (otherTile.IsWalkable && otherTile.Bomb == null)
                            walkableSpotsAround.Add(otherTile);

                        if (otherTile.Player != null && otherTile.Player.Id != this.MyPlayer.Id)
                            otherPlayerAroundCount++;
                    }
                }

                tile.WalkableSpotsAround = walkableSpotsAround;
                tile.LeadsToBeStuck = walkableSpotsAround.Count == 0;
                tile.OtherPlayerAroundCount = otherPlayerAroundCount;
            }

            foreach (var bomb in this.Bombs)
            {
                this.UpdateMustAvoid(bomb, Direction.Up);
                this.UpdateMustAvoid(bomb, Direction.Down);
                this.UpdateMustAvoid(bomb, Direction.Left);
                this.UpdateMustAvoid(bomb, Direction.Right);
            }
        }

        private static readonly Direction[] AllDirections =
        {
            Direction.Up, Direction.Down, Direction.Left, Direction.Right
        };

        private void UpdateMustAvoid(Bomb bomb, Direction direction)
        {
            var tile = this[bomb.X, bomb.Y];
            var bombCountdown = Math.Min(bomb.Countdown, tile.TicksBeforeExplosion);

            for (var i = 1; i <= bomb.Range; i++)
            {
                if (!this.TryGetTileRelativeTo(tile, direction, out tile))
                    return;

                if (tile.TileChar == '.' || tile.TileChar == '*')
                {
                    // tile.MustAvoid = true;
                    if (bombCountdown < tile.TicksBeforeExplosion)
                        tile.TicksBeforeExplosion = bombCountdown;
                }
                
                else return;
            }
        }

        private Bomb FindActiveBombAt(int x, int y)
        {
            return this.Bombs.FirstOrDefault(b => b.X == x && b.Y == y);
        }

        private Player FindAlivePlayerAt(int x, int y)
        {
            return this.AllPlayers.FirstOrDefault(p => p.X == x && p.Y == y);
        }

        private Bonus FindDroppedBonusIndexAt(int x, int y)
        {
            return this.Bonuses.FirstOrDefault(b => b.X == x && b.Y == y);
        }

        public bool IsOutOfBound(int x, int y)
        {
            if (x < 0 || y < 0 || x >= this.Width || y >= this.Height)
                return true;

            var index = y * this.Width + x;
            return index >= this._state.Tiles.Length;
        }

        public bool TryGetTileRelativeTo(TileInfo tile, Direction direction, out TileInfo otherTile)
        {
            return this.TryGetTileRelativeTo(tile.X, tile.Y, direction, out otherTile);
        }

        public bool TryGetTileRelativeTo(int x, int y, Direction direction, out TileInfo otherTile)
        {
            otherTile = null;

            switch (direction)
            {
                case Direction.Up:
                    y--;
                    break;
                case Direction.Down:
                    y++;
                    break;
                case Direction.Left:
                    x--;
                    break;
                case Direction.Right:
                    x++;
                    break;
            }

            if (this.IsOutOfBound(x, y))
                return false;

            otherTile = this[x, y];
            return true;
        }
    }
}