namespace MyBot
{
    public enum TilePathIntent
    {
        Unknown,
        GetBonus,
        DestroyBlock,
        AttackPlayer,
        AvoidExplosion
    }
}