using System.Collections.Generic;

namespace MyBot
{
    public class OperationContext
    {
        public OperationContext(GameState state, string myPlayerId)
        {
            this.AccessibleTiles = new List<TileInfo>(state.Width * state.Height);
            this.TilePaths = new Dictionary<TileInfo, TilePath>();
            this.State = new EnhancedState(state, myPlayerId);
            this.MyPlayerId = myPlayerId;
        }

        public List<TileInfo> AccessibleTiles { get; }
        
        public Dictionary<TileInfo, TilePath> TilePaths { get; }
        
        public EnhancedState State { get; }
        
        public string MyPlayerId { get; }

        public void Refresh(GameState state)
        {
            this.State.Refresh(state);
        }
    }
}