using System;
using System.Collections.Generic;
using System.Linq;

namespace MyBot
{
    public class GameStateHandler
    {
        private Random _rng;
        private GameAction _lastAction;

        public GameStateHandler(GameState state, string myPlayerId)
        {
            this._rng = new Random();
            this.Context = new OperationContext(state, myPlayerId);
            this.Pathfinding = new Pathfinding(this.Context);
        }

        public OperationContext Context { get; }
        public Pathfinding Pathfinding { get; }
        public TilePath LastPath { get; private set; }

        private static readonly Dictionary<GameAction, Direction> GameMoveActionToDirection = new Dictionary<GameAction, Direction>
        {
            [GameAction.Left] = Direction.Left,
            [GameAction.Right] = Direction.Right,
            [GameAction.Up] = Direction.Up,
            [GameAction.Down] = Direction.Down,
        };

        public void Refresh(GameState state)
        {
            this.RefreshTiles(state);
            this.UpdateAccessibleTiles();
            this.ComputeDecisionProperties();
            this.HandleSuddenDeathTilesToAvoid();
            this.ComputeAccessibleTilePaths();
        }

        private readonly Dictionary<int, int> _wallCountBeforeSuddenDeath = new Dictionary<int, int>();

        private void HandleSuddenDeathTilesToAvoid()
        {
            var minWidthHeight = Math.Min(this.Context.State.Width, this.Context.State.Height) / 2;

            if (this._wallCountBeforeSuddenDeath.Count == 0)
            {
                for (var idx = 0; idx < minWidthHeight; idx++)
                {
                    var tiles = this.GetUniqueTilesAtRingIndex(idx);
                    this._wallCountBeforeSuddenDeath[idx] = tiles.Count(t => t.TileChar == '#');
                }
            }

            if (this.Context.State.IsSuddenDeathEnabled)
            {
                for (var idx = 0; idx < minWidthHeight; idx++)
                {
                    var tiles = this.GetUniqueTilesAtRingIndex(idx).ToList();
                    var actualWallCount = tiles.Count(t => t.TileChar == '#');

                    if (this._wallCountBeforeSuddenDeath.TryGetValue(idx, out var initialWallCount) && actualWallCount > initialWallCount)
                    {
                        // Console.WriteLine($"Avoiding {tiles.Count} tiles at ring index {idx}");

                        foreach (var tile in tiles)
                            tile.ThreathenedBySuddenDeath = true;
                    }
                }
            }
        }

        private IEnumerable<TileInfo> GetUniqueTilesAtRingIndex(int idx)
        {
            return new HashSet<TileInfo>(this.GetTilesAtRingIndex(idx));
        }

        private IEnumerable<TileInfo> GetTilesAtRingIndex(int idx)
        {
            var lowWidth = idx;
            var highWidth = this.Context.State.Width - idx - 1;

            var lowHeight = idx;
            var highHeight = this.Context.State.Height - idx - 1;

            foreach (var tile in this.Context.State.Tiles)
            {
                if (tile.X == lowWidth && tile.Y >= lowHeight && tile.Y <= highHeight)
                    yield return tile;

                if (tile.X == highWidth && tile.Y >= lowHeight && tile.Y <= highHeight)
                    yield return tile;

                if (tile.Y == lowHeight && tile.X >= lowWidth && tile.X <= highWidth)
                    yield return tile;

                if (tile.Y == highHeight && tile.X >= lowWidth && tile.X <= highWidth)
                    yield return tile;
            }
        }

        public GameAction GetAction(GameState state)
        {
            this.Refresh(state);

            TilePath bestPath = null;
            var bestAction = GameAction.Stay;

            var player = this.Context.State.MyPlayer;
            var playerName = player.Name;

            //*
            // check if can reuse last chosen path
            if (this.CanReuseLastPath())
            {
                this.LastPath.RemoveFirstTile();

                var equivalent = this.Context.TilePaths.Values.FirstOrDefault(p => p.Equals(this.LastPath));
                if (equivalent != null)
                {
                    equivalent.Intent = this.LastPath.Intent;
                    equivalent.Id = this.LastPath.Id;
                    bestPath = equivalent;
                    bestAction = bestPath.GetAction();

                    if (playerName == "myBotName1")
                    {
                        // Console.WriteLine($"[{this._context.State.Tick}] - [{playerName}] - [{x}:{y}]: can continue on {equivalent} by going {bestAction}");
                    }
                }
            }
            //*/

            if (bestPath == null)
            {
                bestAction = this.GetBestPathAction(out bestPath);
                if (playerName == "myBotName1")
                {
                    // Console.WriteLine($"[{this._context.State.Tick}] - [{playerName}] - [{x}:{y}]: new path {bestPath} by going {bestAction}");
                }
            }

            if (this.IsSuicideToGoTo(bestAction))
            {
                bestAction = GameAction.Stay;
                // bestPath = null;
            }

            this.LastPath = bestPath;
            this._lastAction = bestAction;

            if (playerName == "myBotName1")
            {
                // Console.WriteLine($"[{this.Context.State.Tick}] - [{playerName}] - [{x}:{y}]: ticks before explosion: {playerTile.TicksBeforeExplosion}");
            }

            // Console.WriteLine($"[{this._context.State.Tick}] - [{this._context.MyPlayerId}]: {action} ({watch.Elapsed.TotalSeconds}) | {bestPath}");
            return bestAction;
        }

        private static readonly Dictionary<TilePathIntent, Func<TilePath, bool>> IntentVerifiers = new Dictionary<TilePathIntent, Func<TilePath, bool>>
        {
            // [TilePathIntent.AvoidExplosion] = AvoidExplosionComparer.MatchesIntent,
            [TilePathIntent.GetBonus] = GetBonusComparer.MatchesIntent,
            [TilePathIntent.DestroyBlock] = DestroyBlockComparer.MatchesIntent,
            [TilePathIntent.AttackPlayer] = AttackPlayerComparer.MatchesIntent,
        };

        private bool CanReuseLastPath()
        {
            if (this.LastPath == null || this.LastPath.Length <= 1)
                return false;

            if (this.LastPath[1].X != this.Context.State.MyPlayer.X || this.LastPath[1].Y != this.Context.State.MyPlayer.Y)
                return false;

            if (this._lastAction == GameAction.Stay || this._lastAction == GameAction.Bomb)
                return false;

            if (IntentVerifiers.TryGetValue(this.LastPath.Intent, out var verifier))
            {
                if (!verifier(this.LastPath))
                    return false;
            }

            if (this.LastPath.Intent == TilePathIntent.AvoidExplosion && this.LastPath.Tiles.Any(t => t.IsWalkable == false))
                return false;

            if (this.LastPath.LeadsToDeath)
                return false;

            return true;
        }

        private bool IsSuicideToGoTo(GameAction moveAction)
        {
            var player = this.Context.State.MyPlayer;
            var playerTile = this.Context.State[player.X, player.Y];

            return GameMoveActionToDirection.TryGetValue(moveAction, out var bestDirection) &&
                   this.Context.State.TryGetTileRelativeTo(playerTile, bestDirection, out var nextTile) &&
                   (nextTile.TicksBeforeExplosion == 1 || nextTile.TicksBeforeExplosion == 2) &&
                   playerTile.TicksBeforeExplosion > 2;
        }

        private void RefreshTiles(GameState state)
        {
            this.Context.Refresh(state);
        }

        private void UpdateAccessibleTiles()
        {
            this.Context.AccessibleTiles.Clear();

            var myPlayer = this.Context.State.MyPlayer;
            var visitedTileIndexes = new HashSet<int>();
            var tileIndexesToVisit = new Queue<int>();

            tileIndexesToVisit.Enqueue(this.Context.State[myPlayer.X, myPlayer.Y].Index);

            while (tileIndexesToVisit.Count > 0)
            {
                var index = tileIndexesToVisit.Dequeue();
                if (visitedTileIndexes.Contains(index))
                    continue;

                visitedTileIndexes.Add(index);

                var tile = this.Context.State.Tiles[index];
                if (!tile.IsWalkable)
                    continue;

                this.Context.AccessibleTiles.Add(tile);

                if (this.Context.State.TryGetTileRelativeTo(tile, Direction.Up, out var adjacentTile))
                    tileIndexesToVisit.Enqueue(adjacentTile.Index);

                if (this.Context.State.TryGetTileRelativeTo(tile, Direction.Down, out adjacentTile))
                    tileIndexesToVisit.Enqueue(adjacentTile.Index);

                if (this.Context.State.TryGetTileRelativeTo(tile, Direction.Left, out adjacentTile))
                    tileIndexesToVisit.Enqueue(adjacentTile.Index);

                if (this.Context.State.TryGetTileRelativeTo(tile, Direction.Right, out adjacentTile))
                    tileIndexesToVisit.Enqueue(adjacentTile.Index);
            }
        }

        private void ComputeDecisionProperties()
        {
            foreach (var tile in this.Context.AccessibleTiles)
            {
                foreach (var otherTile in this.Context.AccessibleTiles)
                    otherTile.CanBeReachedByBomb = false;

                this.UpdateTileDestructibleBlockCountAndEnemyCount(tile, Direction.Up);
                this.UpdateTileDestructibleBlockCountAndEnemyCount(tile, Direction.Down);
                this.UpdateTileDestructibleBlockCountAndEnemyCount(tile, Direction.Left);
                this.UpdateTileDestructibleBlockCountAndEnemyCount(tile, Direction.Right);
                
                tile.CanBeReachedByBomb = true;
                tile.IsSafeToDropBomb = tile.Bomb == null && this.Context.AccessibleTiles.Any(t => t.CanBeReachedByBomb == false);
            }
        }

        private void UpdateTileDestructibleBlockCountAndEnemyCount(TileInfo tile, Direction direction)
        {
            var currTile = tile;
            for (var i = 1; i <= this.Context.State.MyPlayer.BombRange; i++)
            {
                if (!this.Context.State.TryGetTileRelativeTo(currTile, direction, out currTile))
                    return;

                if (currTile.TileChar == '#')
                    return; // do not go further

                if (currTile.TileChar == '+')
                {
                    tile.DestructibleBlockCount++;
                    return; // do not go further
                }

                currTile.CanBeReachedByBomb = true;

                if (currTile.Player != null && currTile.Player.Id != this.Context.State.MyPlayer.Id)
                    tile.EnemyCount++;
            }
        }

        private void ComputeAccessibleTilePaths()
        {
            this.Pathfinding.ComputePaths();
        }

        private GameAction GetBestPathAction(out TilePath bestPath)
        {
            bestPath = null;
            
            var comparer = this.GetBestComparer();
            var tilePaths = comparer.MatchingPaths.ToList();
            if (tilePaths.Count == 0)
                return GameAction.Stay;
            
            tilePaths.Sort(comparer);
            
            var player = this.Context.State.MyPlayer;
            if (player.Name == "myBotName1")
            {
                // Console.WriteLine($"[{this.Context.State.Tick}] - [{player.Name}] - [{player.X}:{player.Y}]: now using comparer: {comparer.GetType().Name}");
            }
            
            tilePaths.Sort(comparer);
            bestPath = tilePaths[0];
            bestPath.Intent = comparer.Intent;
            bestPath.Id = comparer.Id;
            
            return bestPath.GetAction();
        }

        public TilePathComparer GetBestComparer()
        {
            var player = this.Context.State.MyPlayer;
            var playerTile = this.Context.State[player.X, player.Y];
            var allPaths = this.Context.TilePaths.Values;
            
            var avoidExplosionComparer = new AvoidExplosionComparer(allPaths);

            if (playerTile.MustAvoid)
            {
                return avoidExplosionComparer;
            }

            var getBonusComparer = new GetBonusComparer(allPaths);
            if (getBonusComparer.MatchingPaths.Count > 0)
            {
                return getBonusComparer;
            }

            if (player.BombsLeft == 0)
                return avoidExplosionComparer;
            
            var attackPlayerComparer = new AttackPlayerComparer(allPaths);

            var stillHasBlocksToDestroy = this.Context.State.Tiles.Any(t => t.DestructibleBlockCount > 0);
            if (stillHasBlocksToDestroy)
            {
                var destroyBlockComparer = new DestroyBlockComparer(allPaths);
                if (destroyBlockComparer.MatchingPaths.Count == 0)
                {
                    return attackPlayerComparer;
                }

                if (attackPlayerComparer.MatchingPaths.Count > 0 && this._rng.NextDouble() > 0.33)
                    return attackPlayerComparer;
                
                return destroyBlockComparer;
            }
            else
            {
                return attackPlayerComparer;
            }
        }
    }
}