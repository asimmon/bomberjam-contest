using System;
using System.Collections.Generic;
using System.Linq;
using RoyT.AStar;

namespace MyBot
{
    public class TilePath
    {
        private static readonly Random Rng = new Random(42);
        
        public TilePath(OperationContext context, IEnumerable<Position> path)
        {
            this.Tiles = path.Select(pos => context.State[pos.X, pos.Y]).ToList();
            this.StartTile = this.Tiles[0];
            this.EndTile = this.Tiles[^1];
            
            this.ComputeProperties();

            this.RandomNumber = Rng.NextDouble();
        }

        public string Id { get; set; }

        public List<TileInfo> Tiles { get; }

        public TileInfo StartTile { get; }

        public TileInfo EndTile { get; }

        public TilePathIntent Intent { get; set; }
        
        public double RandomNumber { get; }
        
        public int DangerLevel { get; private set; }
        
        public bool LeadsToDeath { get; private set; }
        
        public int Length => this.Tiles.Count;

        public TileInfo this[int index]
        {
            get => this.Tiles[index];
        }  

        private void ComputeProperties()
        {
            this.DangerLevel = this.ComputeDangerLevel();
            this.LeadsToDeath = this.ComputeLeadsToDeath();
        }

        private int ComputeDangerLevel()
        {
            return this.Tiles.Count(t => t.MustAvoid);
        }

        private bool ComputeLeadsToDeath()
        {
            var thisDanger = 0;

            for (var i = 0; i < this.Length; i++)
            {
                var tile = this[i];
                var countDownWhenThere = tile.TicksBeforeExplosion - i;

                if (countDownWhenThere >= 0 && countDownWhenThere <= 1)
                    thisDanger++;
            }

            return thisDanger > 0;
        }

        private bool Equals(TilePath other)
        {
            if (this.Tiles.Count != other.Tiles.Count)
                return false;

            for (var i = 0; i < this.Tiles.Count; i++)
            {
                if (!this.Tiles[i].Equals(other.Tiles[i]))
                    return false;
            }

            return true;
        }

        public void RemoveFirstTile()
        {
            if (this.Length <= 1) throw new InvalidOperationException("Not enough tiles");
            this.Tiles.RemoveAt(0);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            if (obj.GetType() != this.GetType()) return false;
            return this.Equals((TilePath)obj);
        }

        public override int GetHashCode()
        {
            return (this.Tiles != null ? this.Tiles.GetHashCode() : 0);
        }

        public GameAction GetAction()
        {
            if (this.Length > 4 &&
                this.Intent == TilePathIntent.DestroyBlock &&
                this.StartTile.DestructibleBlockCount >= 2 &&
                this.StartTile.IsSafeToDropBomb)
            {
                return GameAction.Bomb;
            }
            
            if (this.Length > 1)
            {
                var start = this.Tiles[0];
                var next = this.Tiles[1];

                var dx = next.X - start.X;
                var dy = next.Y - start.Y;

                if (dx != 0)
                    return dx > 0 ? GameAction.Right : GameAction.Left;

                if (dy != 0)
                    return dy > 0 ? GameAction.Down : GameAction.Up;
            }

            switch (this.Intent)
            {
                case TilePathIntent.GetBonus:
                    return GameAction.Stay;
                case TilePathIntent.DestroyBlock:
                    return GameAction.Bomb;
                case TilePathIntent.AvoidExplosion:
                    return GameAction.Stay;
                case TilePathIntent.AttackPlayer:
                    return GameAction.Bomb;
                default:
                    return GameAction.Stay;
            }
        }

        public override string ToString()
        {
            return $"{this.Intent} ({this.Id}) - {string.Join(",", this.Tiles.Select(t => $"({t.X}:{t.Y})"))}";
        }

        public bool IsChildOf(TilePath other)
        {
            if (this.Length >= other.Length)
                return false;

            for (var i = 0; i < this.Length; i++)
            {
                if (this.Tiles[i].Equals(other.Tiles[i]) == false)
                    return false;
            }

            return true;
        }
    }
}