using System;
using System.Collections.Generic;
using System.Linq;

namespace MyBot
{
    public sealed class GetBonusComparer : TilePathComparer
    {
        public GetBonusComparer(IEnumerable<TilePath> paths)
            : base(paths)
        {
        }
        
        public override TilePathIntent Intent { get; } = TilePathIntent.GetBonus;

        public static bool MatchesIntent(TilePath path)
        {
            // only safe paths with bonuses
            if (path.Tiles.All(t => t.Bonus == null)) return false;
            if (path.LeadsToDeath) return false;
            if (path.Tiles.Any(t => t.MustAvoid)) return false;

            return true;
        }

        protected override IEnumerable<TilePath> FilterPaths(IEnumerable<TilePath> paths)
        {
            return paths.Where(MatchesIntent);
        }

        public override int Compare(TilePath thisPath, TilePath otherPath)
        {
            if (thisPath == null) throw new ArgumentNullException(nameof(thisPath));
            if (otherPath == null) throw new ArgumentNullException(nameof(otherPath));
            
            // assume that all paths are safe
            var thisDistanceToBonus = 0;
            for (var i = 0; i < thisPath.Tiles.Count && thisPath.Tiles[i].Bonus == null; i++)
                thisDistanceToBonus++;
            
            var otherDistanceToBonus = 0;
            for (var i = 0; i < otherPath.Tiles.Count && otherPath.Tiles[i].Bonus == null; i++)
                otherDistanceToBonus++;
            
            if (thisDistanceToBonus < otherDistanceToBonus) return -1;
            if (thisDistanceToBonus > otherDistanceToBonus) return 1;

            return thisPath.RandomNumber.CompareTo(otherPath.RandomNumber);
        }
    }
}