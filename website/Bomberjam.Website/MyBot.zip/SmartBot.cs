using System;
using System.Collections.Generic;
using System.Linq;

namespace MyBot
{
    public class SmartBot
    {
        private readonly bool _logWhenHit;
        private GameStateHandler _handler;

        public SmartBot(bool logWhenHit = false)
        {
            this._logWhenHit = logWhenHit;
        }

        private readonly List<string> _history = new List<string>();

        public GameAction GetAction(GameState state, string myPlayerId)
        {
            if (this._handler == null)
                this._handler = new GameStateHandler(state, myPlayerId);

            if (this._logWhenHit)
            {
                var player = this._handler.Context.State.MyPlayer;
                var msg = $"player {myPlayerId} tick {state.Tick} coords {player.X}:{player.Y}";
                var path = this._handler.LastPath == null ? "" : this._handler.LastPath.ToString();
                this._history.Add($"  {msg} | {path}");

                if (player.Respawning == 10)
                {
                    Console.WriteLine("hit");
                    var tail = this._history.TakeLast(15);
                    foreach (var s in tail)
                        Console.WriteLine(s);
                }
            }

            return this._handler.GetAction(state);
        }
    }
}