using System.Collections.Generic;

namespace MyBot
{
    public class TileInfo
    {
        public int X { get; set; }
        public int Y { get; set; }
        public int Index { get; set; }
        public char TileChar { get; set; }

        public bool MustAvoid => this.ThreathenedBySuddenDeath || this.TicksBeforeExplosion < int.MaxValue;
        public bool LeadsToDeath => this.TicksBeforeExplosion == 1 || this.TicksBeforeExplosion == 2;

        public int TicksBeforeExplosion { get; set; }
        public bool IsWalkable { get; set; }
        public bool IsSafeToDropBomb { get; set; }
        public bool ThreathenedBySuddenDeath { get; set; }

        public Bomb Bomb { get; set; }
        public Player Player { get; set; }
        public Bonus Bonus { get; set; }
        
        public int DestructibleBlockCount { get; set; }
        public int EnemyCount { get; set; }
        
        public bool CanBeReachedByBomb { get; set; }
        public bool LeadsToBeStuck { get; set; }
        public int OtherPlayerAroundCount { get; set; }
        public List<TileInfo> WalkableSpotsAround { get; set; }

        private bool Equals(TileInfo other)
        {
            return this.X == other.X && this.Y == other.Y;
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            if (obj.GetType() != this.GetType()) return false;
            return this.Equals((TileInfo)obj);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                // ReSharper disable twice NonReadonlyMemberInGetHashCode
                return (this.X * 397) ^ this.Y;
            }
        }

        public override string ToString()
        {
            return $"{this.X}:{this.Y} ticksBeforeExplosion: {this.TicksBeforeExplosion} isSafeToDropBomb: {this.IsSafeToDropBomb}";
        }
    }
}