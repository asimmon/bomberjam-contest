using System;
using System.Collections.Generic;
using System.Linq;

namespace MyBot
{
    public sealed class AvoidExplosionComparer : TilePathComparer
    {
        public AvoidExplosionComparer(IEnumerable<TilePath> paths)
            : base(paths)
        {
        }
        
        public override TilePathIntent Intent { get; } = TilePathIntent.AvoidExplosion;

        public static bool MatchesIntent(TilePath path)
        {
            if (path.LeadsToDeath || path.Tiles.Any(t => t.MustAvoid))
                return true;

            return path.Tiles.All(t => t.IsWalkable);
        }
        
        protected override IEnumerable<TilePath> FilterPaths(IEnumerable<TilePath> paths)
        {
            return paths;
        }

        public override int Compare(TilePath thisPath, TilePath otherPath)
        {
            if (thisPath == null) throw new ArgumentNullException(nameof(thisPath));
            if (otherPath == null) throw new ArgumentNullException(nameof(otherPath));
            
            // if only one the paths leads to a certain death, prefer the other
            if (thisPath.LeadsToDeath == false && otherPath.LeadsToDeath) return -1;
            if (thisPath.LeadsToDeath && otherPath.LeadsToDeath == false) return 1;

            // both paths leads to death, take the one that need to walk more before dying
            if (thisPath.LeadsToDeath && otherPath.LeadsToDeath)
            {
                var thisTileCountUntilDeath = 0;
                for (var i = 0; i < thisPath.Tiles.Count && thisPath.Tiles[i].LeadsToDeath == false; i++)
                    thisTileCountUntilDeath++;

                var otherTileCountUntilDeath = 0;
                for (var i = 0; i < otherPath.Tiles.Count && otherPath.Tiles[i].LeadsToDeath == false; i++)
                    otherTileCountUntilDeath++;

                if (thisTileCountUntilDeath > otherTileCountUntilDeath) return -1;
                if (thisTileCountUntilDeath < otherTileCountUntilDeath) return 1;
            }

            if (thisPath.EndTile.MustAvoid == false && otherPath.EndTile.MustAvoid) return -1;
            if (thisPath.EndTile.MustAvoid && otherPath.EndTile.MustAvoid == false) return 1;
            
            var isThisPathFullyDangerous = thisPath.Tiles.All(t => t.MustAvoid);
            var isOtherPathFullyDangerous = otherPath.Tiles.All(t => t.MustAvoid);

            // paths are both fully dangerous, should we move ?
            if (isThisPathFullyDangerous && isOtherPathFullyDangerous)
            {
                if (thisPath.EndTile.LeadsToBeStuck == false && otherPath.EndTile.LeadsToBeStuck)
                {
                    if (!thisPath.IsChildOf(otherPath))
                        return -1;
                }

                if (thisPath.EndTile.LeadsToBeStuck && otherPath.EndTile.LeadsToBeStuck == false)
                {
                    if (!otherPath.IsChildOf(thisPath))
                        return 1;
                }

                if (!thisPath.LeadsToDeath && !otherPath.LeadsToDeath)
                {
                    if (thisPath.EndTile.OtherPlayerAroundCount > 0 && otherPath.EndTile.OtherPlayerAroundCount == 0) return -1;
                    if (thisPath.EndTile.OtherPlayerAroundCount == 0 && otherPath.EndTile.OtherPlayerAroundCount > 0) return 1;
                }

                var maxLength = Math.Max(thisPath.Length, otherPath.Length);

                for (var i = 0; i < maxLength; i++)
                {
                    var thisIdx = Math.Min(i, thisPath.Length - 1);
                    var otherIdx = Math.Min(i, otherPath.Length - 1);

                    var thisTile = thisPath[thisIdx];
                    var otherTile = otherPath[otherIdx];

                    var thisTicksBeforeExplosion = thisTile.TicksBeforeExplosion - i;
                    var otherTicksBeforeExplosion = otherTile.TicksBeforeExplosion - i;

                    if (thisTicksBeforeExplosion > otherTicksBeforeExplosion) return -1;
                    if (thisTicksBeforeExplosion < otherTicksBeforeExplosion) return 1;
                }
                
                if (thisPath.StartTile.Bomb == null && otherPath.StartTile.Bomb != null) return -1;
                if (thisPath.StartTile.Bomb != null && otherPath.StartTile.Bomb == null) return 1;

                return otherPath.Length.CompareTo(thisPath.Length);
            }

            if (thisPath.Length != otherPath.Length)
                return thisPath.Length.CompareTo(otherPath.Length);
            
            return thisPath.RandomNumber.CompareTo(otherPath.RandomNumber);
        }
    }
}