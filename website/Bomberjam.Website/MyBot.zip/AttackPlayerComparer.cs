using System;
using System.Collections.Generic;
using System.Linq;

namespace MyBot
{
    public sealed class AttackPlayerComparer : TilePathComparer
    {
        public override TilePathIntent Intent { get; } = TilePathIntent.AttackPlayer;
        
        public AttackPlayerComparer(IEnumerable<TilePath> paths)
            : base(paths)
        {
        }

        public static bool MatchesIntent(TilePath path)
        {
            // only safe paths with other players at the end
            if (path.EndTile.EnemyCount == 0) return false;
            if (path.EndTile.IsSafeToDropBomb == false) return false;
            if (path.LeadsToDeath) return false;
            if (path.Tiles.Any(t => t.MustAvoid)) return false;

            return true;
        }

        protected override IEnumerable<TilePath> FilterPaths(IEnumerable<TilePath> paths)
        {
            return paths.Where(MatchesIntent);
        }

        public override int Compare(TilePath thisPath, TilePath otherPath)
        {
            if (thisPath == null) throw new ArgumentNullException(nameof(thisPath));
            if (otherPath == null) throw new ArgumentNullException(nameof(otherPath));
            
            if (thisPath.EndTile.EnemyCount > otherPath.EndTile.EnemyCount) return -1;
            if (thisPath.EndTile.EnemyCount < otherPath.EndTile.EnemyCount) return 1;
                
            if (thisPath.Length < otherPath.Length) return -1;
            if (thisPath.Length > otherPath.Length) return 1;
            
            return thisPath.RandomNumber.CompareTo(otherPath.RandomNumber);
        }
    }
}