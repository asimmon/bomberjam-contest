using System;
using System.Collections.Generic;
using System.Linq;

namespace MyBot
{
    public sealed class DestroyBlockComparer : TilePathComparer
    {
        public DestroyBlockComparer(IEnumerable<TilePath> paths)
            : base(paths)
        {
        }

        public override TilePathIntent Intent { get; } = TilePathIntent.DestroyBlock;

        public static bool MatchesIntent(TilePath path)
        {
            // only safe paths with destructible blocks
            if (path.EndTile.DestructibleBlockCount == 0) return false;
            if (path.EndTile.IsSafeToDropBomb == false) return false;
            if (path.LeadsToDeath) return false;
            if (path.Tiles.Any(t => t.MustAvoid)) return false;

            return true;
        }

        protected override IEnumerable<TilePath> FilterPaths(IEnumerable<TilePath> paths)
        {
            var allPaths = paths.ToList();
            
            foreach (var path in allPaths.Where(MatchesIntent))
            {
                if (path.Length == 1)
                {
                    var canEscape = allPaths.Where(otherPath =>
                    {
                        if (otherPath.Tiles.Any(t => t.MustAvoid))
                            return false;

                        if (otherPath.Equals(path))
                            return false;

                        if (otherPath.EndTile.WalkableSpotsAround.Count == 1 && otherPath.EndTile.WalkableSpotsAround[0].Equals(path.EndTile))
                            return false;
                        
                        return true;
                    }).ToList();

                    if (canEscape.Count == 0)
                        continue;
                }

                yield return path;
            }
        }

        public override int Compare(TilePath thisPath, TilePath otherPath)
        {
            if (thisPath == null) throw new ArgumentNullException(nameof(thisPath));
            if (otherPath == null) throw new ArgumentNullException(nameof(otherPath));
                
            if (thisPath.EndTile.DestructibleBlockCount > otherPath.EndTile.DestructibleBlockCount) return -1;
            if (thisPath.EndTile.DestructibleBlockCount < otherPath.EndTile.DestructibleBlockCount) return 1;
                
            if (thisPath.Length < otherPath.Length) return -1;
            if (thisPath.Length > otherPath.Length) return 1;
            
            if (thisPath.EndTile.EnemyCount > otherPath.EndTile.EnemyCount) return -1;
            if (thisPath.EndTile.EnemyCount < otherPath.EndTile.EnemyCount) return 1;

            return thisPath.RandomNumber.CompareTo(otherPath.RandomNumber);
        }
    }
}