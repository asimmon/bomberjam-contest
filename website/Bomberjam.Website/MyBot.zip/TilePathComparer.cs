using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace MyBot
{
    public abstract class TilePathComparer : IComparer<TilePath>
    {
        private static int _counter;
        
        public TilePathComparer(IEnumerable<TilePath> paths)
        {
            // ReSharper disable once VirtualMemberCallInConstructor
            this.MatchingPaths = this.FilterPaths(paths).ToList();

            var count = Interlocked.Increment(ref _counter);
            this.Id = count.ToString().PadLeft(7, '0');
        }
        
        public string Id { get; }
        
        public List<TilePath> MatchingPaths { get; }
        
        public abstract TilePathIntent Intent { get; }
        
        protected abstract IEnumerable<TilePath> FilterPaths(IEnumerable<TilePath> paths);

        public abstract int Compare(TilePath thisPath, TilePath otherPath);
    }
}