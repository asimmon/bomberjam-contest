using RoyT.AStar;

namespace MyBot
{
    public class Pathfinding
    {
        private readonly Position[,] _allPositions;
        private readonly OperationContext _context;
        private readonly Grid _unsafeGrid;
        private readonly Grid _safeGrid;

        public Pathfinding(OperationContext context)
        {
            this._context = context;
            this._allPositions = new Position[this._context.State.Width, this._context.State.Height];
            this._unsafeGrid = new Grid(this._context.State.Width, this._context.State.Height);
            this._safeGrid = new Grid(this._context.State.Width, this._context.State.Height);
            
            for (var y = 0; y < this._context.State.Height; y++)
            for (var x = 0; x < this._context.State.Width; x++)
                this._allPositions[x, y] = new Position(x, y);
        }

        public void ComputePaths()
        {
            this._context.TilePaths.Clear();
            
            foreach (var tile in this._context.State.Tiles)
            {
                var position = this._allPositions[tile.X, tile.Y];
                
                if (tile.IsWalkable)
                {
                    this._unsafeGrid.UnblockCell(position);
                    
                    if (tile.MustAvoid)
                        this._safeGrid.BlockCell(position);
                    else
                        this._safeGrid.UnblockCell(position);
                }
                else
                {
                    this._unsafeGrid.BlockCell(position);
                    this._safeGrid.BlockCell(position);
                }
            }

            var playerPosition = this._allPositions[this._context.State.MyPlayer.X, this._context.State.MyPlayer.Y];
            
            foreach (var tile in this._context.AccessibleTiles)
            {
                var destPos = this._allPositions[tile.X, tile.Y];

                var positions = this._safeGrid.GetPath(playerPosition, destPos, MovementPatterns.LateralOnly);
                if (positions == null || positions.Length == 0)
                    positions = this._unsafeGrid.GetPath(playerPosition, destPos, MovementPatterns.LateralOnly);

                this._context.TilePaths[tile] = new TilePath(this._context, positions);
            }
        }
    }
}