﻿using System;
using System.Diagnostics;
using System.Globalization;
using Newtonsoft.Json;

namespace MyBot
{
    public static class Program
    {
        public static void Main()
        {
            // 1. Send your player name
            // Console.Out.WriteLine + Flush is used instead of Console.WriteLine to avoid buffering, because has to be sent quickly
            Console.Out.WriteLine("0:Smart");
            Console.Out.Flush();

            // 2. Retrieve your player id
            var myPlayerId = Console.In.ReadLine();
            if (!int.TryParse(myPlayerId, NumberStyles.Integer, CultureInfo.InvariantCulture, out _))
                throw new Exception("Could not retrieve player ID from stdin");

            var bot = new SmartBot();

            while (true)
            {
                // 3. Retrieve the game current state
                var jsonState = Console.In.ReadLine();
                if (jsonState == null)
                {
                    break;
                }

                var state = JsonConvert.DeserializeObject<GameState>(jsonState);

                try
                {
                    // 4. Send your desired action
                    // var playerAction = Actions[Rng.Next(Actions.Length)];
                    var action = bot.GetAction(state, myPlayerId);
                    Console.Out.WriteLine(state.Tick.ToString(CultureInfo.InvariantCulture) + ":" + action.ToString().ToLowerInvariant());
                    Console.Out.Flush();
                }
                catch (Exception ex)
                {
                    // DO NOT use Console.WriteLine otherwise it will be sent to the bot process
                    Debug.WriteLine(ex);
                }
            }
        }
    }
}