﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace MyBot
{
    [JsonObject(MemberSerialization.OptIn)]
    public class GameState
    {
        [JsonProperty("isFinished")]
        public bool IsFinished { get; set; }

        [JsonProperty("tick")]
        public int Tick { get; set; }

        [JsonProperty("tiles")]
        public string Tiles { get; set; }

        [JsonProperty("players")]
        public IReadOnlyDictionary<string, Player> Players { get; set; }

        [JsonProperty("bombs")]
        public IReadOnlyDictionary<string, Bomb> Bombs { get; set; }

        [JsonProperty("bonuses")]
        public IReadOnlyDictionary<string, Bonus> Bonuses { get; set; }

        [JsonProperty("width")]
        public int Width { get; set; }

        [JsonProperty("height")]
        public int Height { get; set; }

        [JsonProperty("suddenDeathCountdown")]
        public short SuddenDeathCountdown { get; set; }

        [JsonProperty("isSuddenDeathEnabled")]
        public bool SuddenDeathEnabled { get; set; }
    }

    [JsonObject(MemberSerialization.OptIn)]
    public class Bonus
    {
        [JsonProperty("x")]
        public int X { get; set; }

        [JsonProperty("y")]
        public int Y { get; set; }

        [JsonProperty("kind")]
        public string Kind { get; set; }
    }

    [JsonObject(MemberSerialization.OptIn)]
    public class Bomb
    {
        [JsonProperty("x")]
        public int X { get; set; }

        [JsonProperty("y")]
        public int Y { get; set; }

        [JsonProperty("playerId")]
        public string PlayerId { get; set; }

        [JsonProperty("countdown")]
        public int Countdown { get; set; }

        [JsonProperty("range")]
        public int Range { get; set; }
    }

    [JsonObject(MemberSerialization.OptIn)]
    public class Player
    {
        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("x")]
        public int X { get; set; }

        [JsonProperty("y")]
        public int Y { get; set; }

        [JsonProperty("bombsLeft")]
        public int BombsLeft { get; set; }

        [JsonProperty("maxBombs")]
        public int MaxBombs { get; set; }

        [JsonProperty("bombRange")]
        public int BombRange { get; set; }

        [JsonProperty("isAlive")]
        public bool IsAlive { get; set; }

        [JsonProperty("respawning")]
        public int Respawning { get; set; }

        [JsonProperty("score")]
        public int score { get; set; }

        [JsonProperty("color")]
        public int Color { get; set; }

        [JsonProperty("hasWon")]
        public bool HasWon { get; set; }
    }

    public enum GameAction
    {
        Stay,
        Left,
        Right,
        Up,
        Down,
        Bomb,
    }

    [JsonObject(MemberSerialization.OptIn)]
    public class GameStateStep
    {
        [JsonProperty("state")]
        public GameState State { get; set; }

        [JsonProperty("actions")]
        public IDictionary<string, GameAction?> Actions { get; set; }
    }
}