#!/bin/sh

./bomberjam --output replay.json "node MyBot.js" "node MyBot.js" "node MyBot.js" "node MyBot.js"